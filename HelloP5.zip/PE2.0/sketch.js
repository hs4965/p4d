/**
* Erika Mesh
* IGME-609: p5.js Demo
*/ 

/**
* setup : Initialization runs once; called automatically
* Summarize code that you add
*/
function setup() {
  createCanvas(400, 600);
}

/**
* draw : Loops forever; called automatically
* Summarize code that you add
*/
function draw() {
 background(50);

   //car
   line(157, 430, 242, 430);
   line(55, 430, 82, 430);
   line(317, 430, 344, 430);
   line(55, 430, 55, 380);
   line(344, 430, 344, 380);
   fill('rgba(100%,0%,100%,0.5)');
   arc(280, 430, 100, 100, PI, TWO_PI);
   fill('rgba(100%,0%,100%,0.5)');
   arc(120, 430, 100, 100, PI, TWO_PI);
   fill('rgba(100%,0%,100%,0.5)');
   arc(200, 360, 150, 150, PI, TWO_PI);
   fill(50);
   arc(120, 430, 75, 80, PI, TWO_PI);
   fill(50);
   arc(280, 430, 75, 80, PI, TWO_PI);
   strokeWeight(3);
	 stroke(255);
   line(55, 380, 124, 360);
   line(344, 380, 275, 360);
   line(124, 360, 275, 360);
   line(109, 365, 290, 365);
   //wheel
   fill(255, 204, 0);
   ellipse(120, 425, 50, 50);
   ellipse(280, 425, 50, 50);
   //window
   fill(255,204,100);
   rect(190, 310, 45, 45, 20, 20, 0, 0);
   //luaggage
   fill(color(0, 0, 255));
   rect(150, 234, 100, 50);
   fill(255, 204, 100);
   arc(200, 234, 70, 70, PI, TWO_PI);
   fill(50);
   arc(200, 234, 50, 50, PI, TWO_PI);
   fill(255, 204, 100);
   triangle(200, 245, 180, 265, 220, 265);
   beginShape(TRIANGLES);
	 vertex(30, 95);
	 vertex(40, 20);
	 vertex(50, 95);
	 vertex(60, 20);
	 vertex(70, 95);
	 vertex(80, 20);
	 endShape();
   
    beginShape(TRIANGLES);
	 vertex(370, 95);
	 vertex(360, 20);
	 vertex(350, 95);
	 vertex(340, 20);
	 vertex(330, 95);
	 vertex(320, 20);
	 endShape();
   
   //ground
   fill('rgba(0,255,0, 0.25)'); 
   beginShape(TRIANGLE_STRIP);
	 vertex(430, 525);
   vertex(400, 580);
   vertex(370, 525);
	 vertex(340, 580);
	 vertex(310, 525);
	 vertex(280, 580);
	 vertex(250, 525);
	 vertex(220, 580);
	 vertex(190, 525);
   vertex(160, 580);
	 vertex(130, 525);
	 vertex(100, 580);
	 vertex(70, 525);
	 vertex(40, 580);
	 vertex(10, 525);
   vertex(-20, 580);
   vertex(-50, 525); 
	 endShape();
}

 